# Migration: add status index to registrations table
# Depends on existing 0002_initial from teammates

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("tickets", "0002_initial"),
    ]

    operations = [
        migrations.AddIndex(
            model_name="registration",
            index=models.Index(fields=["status"], name="registratio_status_9f3a12_idx"),
        ),
    ]
