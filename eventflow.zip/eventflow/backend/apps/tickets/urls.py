from django.urls import path

from . import views

urlpatterns = [
    # ── Ticket Tiers ──────────────────────────────────────────────────────────
    path(
        "events/<uuid:event_pk>/tiers/",
        views.TierListCreateView.as_view(),
        name="tier-list-create",
    ),
    path(
        "tiers/<uuid:pk>/",
        views.TierDetailView.as_view(),
        name="tier-detail",
    ),

    # ── Registration ──────────────────────────────────────────────────────────
    path(
        "events/<uuid:event_pk>/register/",
        views.RegisterView.as_view(),
        name="event-register",
    ),
    path(
        "my-tickets/",
        views.MyRegistrationsView.as_view(),
        name="my-tickets",
    ),
    path(
        "registrations/<uuid:pk>/",
        views.RegistrationDetailView.as_view(),
        name="registration-detail",
    ),
    path(
        "registrations/<uuid:pk>/cancel/",
        views.CancelRegistrationView.as_view(),
        name="registration-cancel",
    ),

    # ── Organizer: Attendee Management ────────────────────────────────────────
    path(
        "events/<uuid:event_pk>/attendees/",
        views.AttendeeListView.as_view(),
        name="attendee-list",
    ),
    path(
        "events/<uuid:event_pk>/checkin/",
        views.CheckInView.as_view(),
        name="event-checkin",
    ),
    path(
        "events/<uuid:event_pk>/attendees/export/",
        views.AttendeeExportView.as_view(),
        name="attendee-export",
    ),
]
