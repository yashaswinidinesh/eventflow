import logging

from django.http import HttpResponse
from rest_framework import generics, status, permissions
from rest_framework.exceptions import NotFound, ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView

from config.permissions import IsOrganizer
from apps.events.models import Event, EventStatus
from .models import Registration, TicketTier, RegistrationStatus
from .serializers import (
    AttendeeSerializer,
    CheckInSerializer,
    RegisterSerializer,
    RegistrationListSerializer,
    RegistrationSerializer,
    TicketTierSerializer,
    TicketTierWriteSerializer,
)
from .services import (
    cancel_registration,
    check_in,
    export_attendees_csv,
    register as do_register,
)

logger = logging.getLogger(__name__)


# ── Ticket Tiers ──────────────────────────────────────────────────────────────

class TierListCreateView(generics.ListCreateAPIView):
    """
    GET  /v1/tickets/events/<event_pk>/tiers/  — list tiers (public)
    POST /v1/tickets/events/<event_pk>/tiers/  — create tier (organizer only)
    """
    pagination_class = None  # tiers are always a small flat list

    def get_permissions(self):
        if self.request.method == "POST":
            return [IsOrganizer()]
        return [permissions.AllowAny()]

    def get_serializer_class(self):
        if self.request.method == "POST":
            return TicketTierWriteSerializer
        return TicketTierSerializer

    def get_queryset(self):
        return TicketTier.objects.filter(event_id=self.kwargs["event_pk"])

    def perform_create(self, serializer):
        try:
            event = Event.objects.get(
                pk=self.kwargs["event_pk"],
                organizer=self.request.user,
            )
        except Event.DoesNotExist:
            raise NotFound("Event not found or you are not the organizer.")
        serializer.save(event=event)


class TierDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET    /v1/tickets/tiers/<pk>/  — tier detail (public)
    PUT    /v1/tickets/tiers/<pk>/  — update (organizer)
    DELETE /v1/tickets/tiers/<pk>/  — delete (organizer; blocked if tickets sold)
    """

    def get_permissions(self):
        if self.request.method == "GET":
            return [permissions.AllowAny()]
        return [IsOrganizer()]

    def get_serializer_class(self):
        if self.request.method in ("PUT", "PATCH"):
            return TicketTierWriteSerializer
        return TicketTierSerializer

    def get_queryset(self):
        if self.request.method == "GET":
            return TicketTier.objects.all()
        return TicketTier.objects.filter(event__organizer=self.request.user)

    def perform_destroy(self, instance):
        if instance.sold > 0:
            raise ValidationError("Cannot delete a tier that already has sold tickets.")
        instance.delete()


# ── Registration ──────────────────────────────────────────────────────────────

class RegisterView(APIView):
    """
    POST /v1/tickets/events/<event_pk>/register/

    Register the authenticated user for an event.

    Request body: { "tier_id": "<uuid>", "quantity": 1 }

    Free event  → 201, status=CONFIRMED, qr_image included
    Paid event  → 201, status=PENDING, payment.checkout_url included

    Error codes:
      400 CAPACITY_EXCEEDED  — not enough tickets left
      400 SALES_CLOSED       — tier's sales_end has passed
      400 INVALID_TIER       — tier does not belong to this event
      403 BANNED             — user account is suspended
      404 NOT_FOUND          — event not found or not published
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, event_pk):
        if request.user.is_banned:
            return Response(
                {"error": {"code": "BANNED", "message": "Your account has been suspended."}},
                status=status.HTTP_403_FORBIDDEN,
            )

        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            event = Event.objects.get(pk=event_pk, status=EventStatus.PUBLISHED)
        except Event.DoesNotExist:
            return Response(
                {"error": {"code": "NOT_FOUND", "message": "Event not found or not published."}},
                status=status.HTTP_404_NOT_FOUND,
            )

        try:
            registration = do_register(
                user=request.user,
                event=event,
                tier_id=str(serializer.validated_data["tier_id"]),
                quantity=serializer.validated_data["quantity"],
            )
        except TicketTier.DoesNotExist:
            return Response(
                {"error": {"code": "INVALID_TIER", "message": "Ticket tier not found for this event."}},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except ValueError as exc:
            msg = str(exc)
            if "remaining" in msg or "available" in msg.lower():
                code = "CAPACITY_EXCEEDED"
            elif "ended" in msg:
                code = "SALES_CLOSED"
            else:
                code = "REGISTRATION_ERROR"
            return Response(
                {"error": {"code": code, "message": msg}},
                status=status.HTTP_400_BAD_REQUEST,
            )

        response_data = RegistrationSerializer(registration).data

        # For paid tiers, inline the checkout URL so the frontend can redirect
        if not registration.tier.is_free:
            from apps.payments.services import create_checkout_session
            checkout = create_checkout_session(registration)
            response_data["payment"] = {
                "checkout_url": checkout["checkout_url"],
                "session_id":   checkout["session_id"],
            }

        logger.info(
            "Registration created: user=%s event=%s tier=%s qty=%d status=%s",
            request.user.email, event.title, registration.tier.name,
            registration.quantity, registration.status,
        )
        return Response(response_data, status=status.HTTP_201_CREATED)


class MyRegistrationsView(generics.ListAPIView):
    """
    GET /v1/tickets/my-tickets/

    The authenticated user's ticket wallet — all their registrations,
    newest first. Supports ?status=CONFIRMED|PENDING|CANCELLED filter.
    """
    serializer_class   = RegistrationListSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = (
            Registration.objects
            .filter(user=self.request.user)
            .select_related("event", "tier")
            .order_by("-created_at")
        )
        status_filter = self.request.query_params.get("status")
        if status_filter:
            qs = qs.filter(status=status_filter.upper())
        return qs


class RegistrationDetailView(generics.RetrieveAPIView):
    """
    GET /v1/tickets/registrations/<pk>/

    Full registration detail for the owner, including QR code image
    for CONFIRMED tickets.
    """
    serializer_class   = RegistrationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return (
            Registration.objects
            .filter(user=self.request.user)
            .select_related("event", "tier")
        )


class CancelRegistrationView(APIView):
    """
    POST /v1/tickets/registrations/<pk>/cancel/

    Cancel the authenticated user's own registration.
    Releases the seat back to the tier's available pool.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            registration = (
                Registration.objects
                .select_related("tier", "user")
                .get(pk=pk, user=request.user)
            )
        except Registration.DoesNotExist:
            return Response(
                {"error": {"code": "NOT_FOUND", "message": "Registration not found."}},
                status=status.HTTP_404_NOT_FOUND,
            )

        try:
            cancel_registration(registration, request.user)
        except ValueError as exc:
            return Response(
                {"error": {"code": "CANCEL_ERROR", "message": str(exc)}},
                status=status.HTTP_400_BAD_REQUEST,
            )

        logger.info(
            "Registration cancelled: user=%s registration=%s",
            request.user.email, pk,
        )
        return Response(
            {"message": "Registration cancelled successfully."},
            status=status.HTTP_200_OK,
        )


# ── Organizer: Attendee Management ────────────────────────────────────────────

class AttendeeListView(generics.ListAPIView):
    """
    GET /v1/tickets/events/<event_pk>/attendees/

    All registrations for an event (organizer only) — CONFIRMED, PENDING, and CANCELLED.
    Summary counts are based on CONFIRMED only.
    Supports ?checked_in=true|false filter.
    """
    serializer_class   = AttendeeSerializer
    permission_classes = [IsOrganizer]
    pagination_class   = None  # custom list() builds its own response shape

    def get_queryset(self):
        qs = (
            Registration.objects
            .filter(
                event_id=self.kwargs["event_pk"],
                event__organizer=self.request.user,
            )
            .select_related("user", "tier")
            .order_by("user__name")
        )
        checked_in = self.request.query_params.get("checked_in")
        if checked_in is not None:
            qs = qs.filter(checked_in=checked_in.lower() == "true")
        return qs

    def list(self, request, *args, **kwargs):
        # Summary stats are CONFIRMED-only (actual seat holders)
        base_qs = Registration.objects.filter(
            event_id=self.kwargs["event_pk"],
            event__organizer=request.user,
            status=RegistrationStatus.CONFIRMED,
        )
        total   = base_qs.count()
        checked = base_qs.filter(checked_in=True).count()

        response = super().list(request, *args, **kwargs)
        response.data = {
            "summary": {
                "total":      total,
                "checked_in": checked,
                "remaining":  total - checked,
            },
            "results": response.data,
        }
        return response


class CheckInView(APIView):
    """
    POST /v1/tickets/events/<event_pk>/checkin/

    Mark an attendee as checked in by scanning their QR code.
    Only the event organizer can do this.

    Request body: { "qr_code": "eventure:reg:<uuid>:<sig>" }

    Success (200): { registration_id, name, email, tier, checked_in_at }

    Error codes:
      400 INVALID_QR         — QR string malformed or HMAC invalid
      400 NOT_CONFIRMED      — registration is PENDING or CANCELLED
      409 ALREADY_CHECKED_IN — attendee already scanned in
      404 NOT_FOUND          — QR not valid for this event
    """
    permission_classes = [IsOrganizer]

    def post(self, request, event_pk):
        serializer = CheckInSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            reg = check_in(
                event_id=str(event_pk),
                organizer=request.user,
                qr_code=serializer.validated_data["qr_code"],
            )
        except ValueError as exc:
            msg = str(exc)
            if "already checked in" in msg.lower():
                return Response(
                    {"error": {"code": "ALREADY_CHECKED_IN", "message": msg}},
                    status=status.HTTP_409_CONFLICT,
                )
            if "invalid qr" in msg.lower():
                return Response(
                    {"error": {"code": "INVALID_QR", "message": msg}},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            if "CONFIRMED" in msg:
                return Response(
                    {"error": {"code": "NOT_CONFIRMED", "message": msg}},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            return Response(
                {"error": {"code": "NOT_FOUND", "message": msg}},
                status=status.HTTP_404_NOT_FOUND,
            )

        logger.info(
            "Check-in: organizer=%s attendee=%s event=%s",
            request.user.email, reg.user.email, reg.event.title,
        )
        return Response({
            "registration_id": str(reg.id),
            "name":            reg.user.name,
            "email":           reg.user.email,
            "tier":            reg.tier.name,
            "checked_in_at":   reg.checked_in_at,
        }, status=status.HTTP_200_OK)


class AttendeeExportView(APIView):
    """
    GET /v1/tickets/events/<event_pk>/attendees/export/

    Download all confirmed attendees as a CSV file.
    Only the event organizer can download this.
    """
    permission_classes = [IsOrganizer]

    def get(self, request, event_pk):
        try:
            event = Event.objects.get(pk=event_pk)
        except Event.DoesNotExist:
            return Response(
                {"error": {"code": "NOT_FOUND", "message": "Event not found."}},
                status=status.HTTP_404_NOT_FOUND,
            )

        try:
            csv_content = export_attendees_csv(event, request.user)
        except PermissionError:
            return Response(
                {"error": {"code": "FORBIDDEN", "message": "You do not own this event."}},
                status=status.HTTP_403_FORBIDDEN,
            )

        response = HttpResponse(csv_content, content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = (
            f'attachment; filename="attendees-{event_pk}.csv"'
        )
        return response
