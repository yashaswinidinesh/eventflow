from rest_framework import serializers
from django.utils import timezone

from .models import TicketTier, Registration, RegistrationStatus


class TicketTierSerializer(serializers.ModelSerializer):
    """Read-only tier info returned publicly."""
    available  = serializers.ReadOnlyField()
    is_free    = serializers.ReadOnlyField()
    is_on_sale = serializers.SerializerMethodField()

    class Meta:
        model  = TicketTier
        fields = [
            "id", "name", "price", "quantity", "sold",
            "available", "is_free", "is_on_sale", "sales_end",
        ]

    def get_is_on_sale(self, obj) -> bool:
        if obj.sales_end is None:
            return True
        return timezone.now() < obj.sales_end


class TicketTierWriteSerializer(serializers.ModelSerializer):
    """Used by organizer to create/update a tier."""

    class Meta:
        model  = TicketTier
        fields = ["name", "price", "quantity", "sales_end"]

    def validate_price(self, value):
        if value < 0:
            raise serializers.ValidationError("Price cannot be negative.")
        return value

    def validate_quantity(self, value):
        if value < 1:
            raise serializers.ValidationError("Quantity must be at least 1.")
        return value

    def validate_sales_end(self, value):
        if value is not None and value <= timezone.now():
            raise serializers.ValidationError("sales_end must be in the future.")
        return value


class RegisterSerializer(serializers.Serializer):
    """Request body for registering for a ticket tier."""
    tier_id  = serializers.UUIDField()
    quantity = serializers.IntegerField(min_value=1, max_value=10)


class RegistrationSerializer(serializers.ModelSerializer):
    """
    Full registration detail — returned to the attendee.
    Includes QR image (base64 PNG) only for CONFIRMED registrations.
    """
    tier        = TicketTierSerializer(read_only=True)
    event_id    = serializers.UUIDField(source="event.id",     read_only=True)
    event_title = serializers.CharField(source="event.title",  read_only=True)
    event_start = serializers.DateTimeField(source="event.start_at", read_only=True)
    qr_image    = serializers.SerializerMethodField()

    class Meta:
        model  = Registration
        fields = [
            "id", "event_id", "event_title", "event_start",
            "tier", "quantity", "status",
            "qr_code", "qr_image",
            "checked_in", "checked_in_at", "created_at",
        ]

    def get_qr_image(self, obj) -> str | None:
        if obj.status != RegistrationStatus.CONFIRMED:
            return None
        from apps.tickets.services import generate_qr_image_b64
        b64 = generate_qr_image_b64(obj.qr_code)
        return f"data:image/png;base64,{b64}"


class RegistrationListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for the attendee's My Tickets list."""
    event_id    = serializers.UUIDField(source="event.id",          read_only=True)
    event_title = serializers.CharField(source="event.title",       read_only=True)
    event_start = serializers.DateTimeField(source="event.start_at", read_only=True)
    tier_name   = serializers.CharField(source="tier.name",         read_only=True)
    is_free     = serializers.BooleanField(source="tier.is_free",   read_only=True)

    class Meta:
        model  = Registration
        fields = [
            "id", "event_id", "event_title", "event_start",
            "tier_name", "is_free", "quantity",
            "status", "checked_in", "created_at",
        ]


class AttendeeSerializer(serializers.ModelSerializer):
    """Organizer view of a registered attendee."""
    name       = serializers.CharField(source="user.name")
    email      = serializers.EmailField(source="user.email")
    tier_name  = serializers.CharField(source="tier.name")
    tier_price = serializers.DecimalField(
        source="tier.price", max_digits=10, decimal_places=2
    )

    class Meta:
        model  = Registration
        fields = [
            "id", "name", "email",
            "tier_name", "tier_price", "quantity",
            "status", "checked_in", "checked_in_at",
            "qr_code", "created_at",
        ]


class CheckInSerializer(serializers.Serializer):
    """Request body sent by organizer when scanning a QR code."""
    qr_code = serializers.CharField(min_length=1)
