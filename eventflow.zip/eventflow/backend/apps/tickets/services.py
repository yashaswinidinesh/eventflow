"""
Tickets & Registration Service — Component 3

All business logic lives here. Views call these functions; no logic in views.

Public API
----------
register(user, event, tier_id, quantity)        -> Registration
cancel_registration(registration, user)          -> None
check_in(event_id, organizer, qr_code)          -> Registration
export_attendees_csv(event, organizer)           -> str

Internal helpers
----------------
generate_qr_payload(registration_id)            -> str
verify_qr_payload(payload)                       -> str | None
generate_qr_image_b64(payload)                  -> str
"""

import base64
import csv
import hashlib
import hmac
import io
import uuid

import qrcode
from django.conf import settings
from django.db import transaction, IntegrityError
from django.utils import timezone

from .models import Registration, RegistrationStatus, TicketTier


# ── QR helpers ────────────────────────────────────────────────────────────────

def generate_qr_payload(registration_id: str) -> str:
    """
    Build an HMAC-SHA256 signed string stored as the QR code value.
    Format: eventure:reg:<uuid>:<first-12-hex-chars-of-hmac>

    The HMAC prevents attendees from crafting fake QR codes.
    """
    sig = hmac.new(
        settings.SECRET_KEY.encode(),
        registration_id.encode(),
        hashlib.sha256,
    ).hexdigest()[:12]
    return f"eventure:reg:{registration_id}:{sig}"


def verify_qr_payload(payload: str) -> str | None:
    """
    Verify a QR payload's HMAC signature.
    Returns the registration_id on success, None if invalid or malformed.
    Uses constant-time comparison to prevent timing attacks.
    """
    try:
        _, _, registration_id, sig = payload.split(":")
    except ValueError:
        return None

    expected = hmac.new(
        settings.SECRET_KEY.encode(),
        registration_id.encode(),
        hashlib.sha256,
    ).hexdigest()[:12]

    if not hmac.compare_digest(sig, expected):
        return None

    return registration_id


def generate_qr_image_b64(payload: str) -> str:
    """Return a base64-encoded PNG of the QR code for the given payload."""
    img = qrcode.make(payload)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


# ── Registration ──────────────────────────────────────────────────────────────

@transaction.atomic
def register(user, event, tier_id: str, quantity: int) -> Registration:
    """
    Register a user for an event tier.

    Flow:
      1. Lock the tier row (SELECT FOR UPDATE) to prevent race conditions.
      2. Validate tier belongs to event and sales window is open.
      3. Check available capacity.
      4. Create Registration:
           Free tier  → status=CONFIRMED, increment sold, queue confirmation email.
           Paid tier  → status=PENDING, caller redirects user to checkout.

    Raises:
      TicketTier.DoesNotExist  — tier_id wrong or doesn't belong to this event.
      ValueError               — capacity, sales window, or duplicate violations.
    """
    tier = TicketTier.objects.select_for_update().get(id=tier_id, event=event)

    # Duplicate registration check
    if Registration.objects.filter(
        user=user, event=event,
        status__in=[RegistrationStatus.CONFIRMED, RegistrationStatus.PENDING],
    ).exists():
        raise ValueError("You are already registered for this event.")

    # Sales window check
    if tier.sales_end is not None and timezone.now() >= tier.sales_end:
        raise ValueError("Ticket sales for this tier have ended.")

    # Capacity check
    if tier.available < quantity:
        raise ValueError(
            f"Only {tier.available} ticket(s) remaining for this tier."
        )

    reg_id  = str(uuid.uuid4())
    payload = generate_qr_payload(reg_id)
    status  = RegistrationStatus.CONFIRMED if tier.is_free else RegistrationStatus.PENDING

    try:
        registration = Registration.objects.create(
            id=reg_id,
            user=user,
            event=event,
            tier=tier,
            quantity=quantity,
            status=status,
            qr_code=payload,
        )
    except IntegrityError:
        # Unique constraint on qr_code fired — extremely unlikely UUID collision,
        # treated as a generic error and surfaced cleanly.
        raise ValueError("Registration could not be created. Please try again.")

    if tier.is_free:
        tier.sold += quantity
        tier.save(update_fields=["sold"])
        try:
            from apps.notifications.tasks import send_confirmation_email
            send_confirmation_email.delay(str(registration.id))
        except Exception:
            pass  # email queue unavailable; registration still succeeds

    return registration


@transaction.atomic
def cancel_registration(registration: Registration, user) -> None:
    """
    Cancel a registration owned by user.

    Rules:
      - Only the registration owner can cancel.
      - Already-cancelled registrations are rejected.
      - Seat is released back to the tier.
      - Cancellation email queued for paid+completed registrations.

    Raises:
      PermissionError — caller does not own the registration.
      ValueError      — registration is already cancelled.
    """
    if str(registration.user_id) != str(user.id):
        raise PermissionError("You do not own this registration.")

    if registration.status == RegistrationStatus.CANCELLED:
        raise ValueError("This registration is already cancelled.")

    registration.status = RegistrationStatus.CANCELLED
    registration.save(update_fields=["status"])

    # Release seat — guard against going below zero
    tier = registration.tier
    tier.sold = max(0, tier.sold - registration.quantity)
    tier.save(update_fields=["sold"])

    try:
        from apps.notifications.tasks import send_cancellation_email
        send_cancellation_email.delay(str(registration.id))
    except Exception:
        pass


# ── Check-in ──────────────────────────────────────────────────────────────────

@transaction.atomic
def check_in(event_id: str, organizer, qr_code: str) -> Registration:
    """
    Mark an attendee as checked in via QR code scan.

    Rules:
      - QR signature is verified before touching the DB.
      - Organizer must own the event.
      - Registration must be CONFIRMED.
      - Cannot check in the same attendee twice.

    Returns the updated Registration on success.
    Raises ValueError with a specific message for each failure mode.
    """
    # Verify HMAC before any DB query
    registration_id = verify_qr_payload(qr_code)
    if registration_id is None:
        raise ValueError("Invalid QR code.")

    try:
        reg = (
            Registration.objects
            .select_for_update()
            .select_related("user", "event", "tier")
            .get(
                id=registration_id,
                event_id=event_id,
                event__organizer=organizer,
            )
        )
    except Registration.DoesNotExist:
        raise ValueError("QR code not valid for this event.")

    if reg.status != RegistrationStatus.CONFIRMED:
        raise ValueError(f"Registration is {reg.status}, not CONFIRMED.")

    if reg.checked_in:
        raise ValueError(
            f"{reg.user.name} is already checked in "
            f"(at {reg.checked_in_at.strftime('%H:%M')})."
        )

    reg.checked_in    = True
    reg.checked_in_at = timezone.now()
    reg.save(update_fields=["checked_in", "checked_in_at"])
    return reg


# ── CSV export ────────────────────────────────────────────────────────────────

def export_attendees_csv(event, organizer) -> str:
    """
    Return a CSV string of all CONFIRMED attendees for an event.
    Only the event organizer may call this.

    Raises PermissionError if organizer does not own the event.
    """
    if str(event.organizer_id) != str(organizer.id):
        raise PermissionError("You do not own this event.")

    registrations = (
        Registration.objects
        .filter(event=event, status=RegistrationStatus.CONFIRMED)
        .select_related("user", "tier")
        .order_by("created_at")
    )

    buf    = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow([
        "Registration ID", "Name", "Email",
        "Tier", "Price (each)", "Quantity",
        "Checked In", "Checked In At", "Registered At",
    ])
    for reg in registrations:
        writer.writerow([
            str(reg.id),
            reg.user.name,
            reg.user.email,
            reg.tier.name,
            str(reg.tier.price),
            reg.quantity,
            "Yes" if reg.checked_in else "No",
            reg.checked_in_at.isoformat() if reg.checked_in_at else "",
            reg.created_at.isoformat(),
        ])

    return buf.getvalue()


# Keep old name as alias so existing imports in views.py still work
def export_csv(event, organizer) -> str:
    return export_attendees_csv(event, organizer)
