import uuid
from django.db import models
from django.conf import settings
from apps.events.models import Event


class TicketTier(models.Model):
    id        = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    event     = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='tiers')
    name      = models.CharField(max_length=80)
    price     = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    quantity  = models.PositiveIntegerField()
    sold      = models.PositiveIntegerField(default=0)
    sales_end = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'ticket_tiers'

    @property
    def available(self):
        return self.quantity - self.sold

    @property
    def is_free(self):
        return self.price == 0


class RegistrationStatus(models.TextChoices):
    PENDING   = 'PENDING',   'Pending'
    CONFIRMED = 'CONFIRMED', 'Confirmed'
    CANCELLED = 'CANCELLED', 'Cancelled'


class Registration(models.Model):
    id           = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user         = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                     related_name='registrations')
    event        = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='registrations')
    tier         = models.ForeignKey(TicketTier, on_delete=models.CASCADE, related_name='registrations')
    quantity     = models.PositiveIntegerField(default=1)
    status       = models.CharField(max_length=20, choices=RegistrationStatus.choices,
                                    default=RegistrationStatus.PENDING)
    qr_code      = models.CharField(max_length=255, unique=True)
    checked_in   = models.BooleanField(default=False)
    checked_in_at = models.DateTimeField(null=True, blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'registrations'
        indexes  = [
            models.Index(fields=['user']),
            models.Index(fields=['event']),
            models.Index(fields=['qr_code']),
        ]
