from django.urls import path

from . import views

urlpatterns = [
    path("checkout-session/",       views.CheckoutSessionView.as_view(), name="checkout-session"),
    path("webhook/",                views.WebhookView.as_view(),         name="payment-webhook"),
    path("<uuid:registration_id>/", views.PaymentDetailView.as_view(),   name="payment-detail"),
]
