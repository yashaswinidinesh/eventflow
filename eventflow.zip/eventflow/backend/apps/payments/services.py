"""
Payments Service — Component 3

Mock Stripe checkout. Swap create_checkout_session() and handle_webhook()
for real Stripe SDK calls when going to production — everything else stays.
"""
import logging
import uuid

from django.conf import settings
from django.db import transaction

from .models import Payment, PaymentStatus

logger = logging.getLogger(__name__)


def create_checkout_session(registration) -> dict:
    """
    Create a mock Stripe checkout session for a PENDING registration.

    Stores a Payment row at PENDING status and returns a checkout_url
    the frontend should redirect the user to.
    """
    session_id = f"mock_sess_{uuid.uuid4().hex[:16]}"
    amount     = registration.tier.price * registration.quantity

    Payment.objects.update_or_create(
        registration=registration,
        defaults={
            "amount":     amount,
            "currency":   "USD",
            "status":     PaymentStatus.PENDING,
            "stripe_ref": session_id,
        },
    )

    checkout_url = (
        f"{settings.FRONTEND_URL}/checkout/mock"
        f"?session={session_id}&reg={registration.id}"
    )

    logger.info(
        "Checkout session created: session=%s registration=%s amount=%s",
        session_id, registration.id, amount,
    )
    return {"checkout_url": checkout_url, "session_id": session_id}


@transaction.atomic
def handle_webhook(payload: dict) -> bool:
    """
    Handle a mock Stripe webhook confirming payment.

    Expected payload: { "session_id": "<mock_sess_...>" }

    On success (atomic):
      1. Payment   → COMPLETED
      2. Registration → CONFIRMED
      3. tier.sold incremented
      4. Confirmation email queued via Celery

    Idempotent — safe to call multiple times with the same session_id.
    Returns True if payment was processed, False if session_id unknown.
    """
    from apps.tickets.models import RegistrationStatus
    from apps.notifications.tasks import send_confirmation_email

    session_id = payload.get("session_id")
    if not session_id:
        logger.warning("Webhook received with no session_id.")
        return False

    try:
        payment = (
            Payment.objects
            .select_for_update()
            .select_related("registration__tier", "registration__user")
            .get(stripe_ref=session_id)
        )
    except Payment.DoesNotExist:
        logger.warning("Webhook: no payment found for session=%s", session_id)
        return False

    # Idempotency — do nothing if already completed
    if payment.status == PaymentStatus.COMPLETED:
        logger.info("Webhook: already completed for session=%s", session_id)
        return True

    payment.status = PaymentStatus.COMPLETED
    payment.save(update_fields=["status"])

    reg        = payment.registration
    reg.status = RegistrationStatus.CONFIRMED
    reg.save(update_fields=["status"])

    tier       = reg.tier
    tier.sold += reg.quantity
    tier.save(update_fields=["sold"])

    send_confirmation_email.delay(str(reg.id))

    logger.info(
        "Payment confirmed: session=%s registration=%s user=%s",
        session_id, reg.id, reg.user.email,
    )
    return True
