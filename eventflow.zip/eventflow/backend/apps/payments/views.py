import logging

from rest_framework import status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.tickets.models import Registration, RegistrationStatus
from .models import Payment
from .serializers import PaymentSerializer
from .services import create_checkout_session, handle_webhook

logger = logging.getLogger(__name__)


class CheckoutSessionView(APIView):
    """
    POST /v1/payments/checkout-session/

    Initiate checkout for a PENDING paid registration.

    Request body: { "registration_id": "<uuid>" }
    Response:     { "checkout_url": "...", "session_id": "..." }
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        reg_id = request.data.get("registration_id")
        if not reg_id:
            return Response(
                {"error": {"code": "MISSING_FIELD", "message": "registration_id is required."}},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            registration = (
                Registration.objects
                .select_related("tier")
                .get(id=reg_id, user=request.user)
            )
        except Registration.DoesNotExist:
            return Response(
                {"error": {"code": "NOT_FOUND", "message": "Registration not found."}},
                status=status.HTTP_404_NOT_FOUND,
            )

        if registration.status != RegistrationStatus.PENDING:
            return Response(
                {"error": {
                    "code":    "INVALID_STATUS",
                    "message": f"Registration is already {registration.status}.",
                }},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if registration.tier.is_free:
            return Response(
                {"error": {"code": "FREE_TIER", "message": "Free tickets need no payment."}},
                status=status.HTTP_400_BAD_REQUEST,
            )

        result = create_checkout_session(registration)
        return Response(result, status=status.HTTP_201_CREATED)


class WebhookView(APIView):
    """
    POST /v1/payments/webhook/

    Mock Stripe webhook. In production Stripe calls this after payment succeeds.
    During development the frontend calls it directly to confirm a mock checkout.

    Always returns 200 — Stripe requires this even on processing errors.
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        handle_webhook(request.data)
        return Response({"received": True}, status=status.HTTP_200_OK)


class PaymentDetailView(APIView):
    """
    GET /v1/payments/<registration_id>/

    Return the payment status for a registration (owner only).
    Used by the frontend to poll after returning from the mock checkout page.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, registration_id):
        try:
            payment = Payment.objects.get(
                registration__id=registration_id,
                registration__user=request.user,
            )
        except Payment.DoesNotExist:
            return Response(
                {"error": {"code": "NOT_FOUND", "message": "Payment not found."}},
                status=status.HTTP_404_NOT_FOUND,
            )
        return Response(PaymentSerializer(payment).data)
