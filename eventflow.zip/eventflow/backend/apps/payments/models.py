import uuid
from django.db import models
from apps.tickets.models import Registration


class PaymentStatus(models.TextChoices):
    PENDING   = 'PENDING',   'Pending'
    COMPLETED = 'COMPLETED', 'Completed'
    FAILED    = 'FAILED',    'Failed'
    REFUNDED  = 'REFUNDED',  'Refunded'


class Payment(models.Model):
    id             = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    registration   = models.OneToOneField(Registration, on_delete=models.CASCADE,
                                          related_name='payment')
    amount         = models.DecimalField(max_digits=10, decimal_places=2)
    currency       = models.CharField(max_length=3, default='USD')
    status         = models.CharField(max_length=20, choices=PaymentStatus.choices,
                                      default=PaymentStatus.PENDING)
    stripe_ref     = models.CharField(max_length=255, blank=True)
    created_at     = models.DateTimeField(auto_now_add=True)
    updated_at     = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'payments'
