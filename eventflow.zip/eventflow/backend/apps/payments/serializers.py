from rest_framework import serializers
from .models import Payment


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model        = Payment
        fields       = ["id", "registration", "amount", "currency", "status", "stripe_ref", "created_at"]
        read_only_fields = fields
