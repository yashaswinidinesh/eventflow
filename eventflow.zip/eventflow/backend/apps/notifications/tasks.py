"""
Celery Tasks — Notifications (Component 4)

All tasks retry up to 3 times with exponential back-off.
In tests, CELERY_TASK_ALWAYS_EAGER=True runs them synchronously.
"""
import base64
import logging
from email.mime.image import MIMEImage

from celery import shared_task
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils import timezone

logger = logging.getLogger(__name__)


def _send_email(to: str, subject: str, template_base: str, context: dict) -> None:
    """Render html + txt templates and send via the configured email backend."""
    html = render_to_string(f"email/{template_base}.html", context)
    text = render_to_string(f"email/{template_base}.txt",  context)
    msg  = EmailMultiAlternatives(
        subject=subject,
        body=text,
        from_email=settings.DEFAULT_FROM_EMAIL,
        to=[to],
    )
    msg.attach_alternative(html, "text/html")
    msg.send()


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_confirmation_email(self, registration_id: str) -> None:
    """
    Send ticket confirmation with embedded QR code image.
    Triggered immediately after free registration or paid webhook confirmation.
    """
    try:
        from apps.tickets.models import Registration
        from apps.tickets.services import generate_qr_image_b64
        from .models import Notification, NotificationStatus

        reg    = Registration.objects.select_related("user", "event", "tier").get(id=registration_id)
        qr_b64 = generate_qr_image_b64(reg.qr_code)

        context = {
            "name":        reg.user.name,
            "event_title": reg.event.title,
            "start_at":    reg.event.start_at.strftime("%A, %B %d %Y at %I:%M %p UTC"),
            "venue_name":  reg.event.venue_name,
            "address":     reg.event.address,
            "tier_name":   reg.tier.name,
            "quantity":    reg.quantity,
        }
        html = render_to_string("email/confirmation.html", context)
        text = render_to_string("email/confirmation.txt",  context)

        msg = EmailMultiAlternatives(
            subject=f"Your ticket for {reg.event.title}",
            body=text,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[reg.user.email],
        )
        msg.mixed_subtype = 'related'
        msg.attach_alternative(html, "text/html")

        qr_img = MIMEImage(base64.b64decode(qr_b64), _subtype='png')
        qr_img.add_header('Content-ID', '<qr_code>')
        qr_img.add_header('Content-Disposition', 'inline', filename='qr_code.png')
        msg.attach(qr_img)
        msg.send()

        Notification.objects.create(
            user=reg.user,
            type="CONFIRMATION",
            payload={"registration_id": registration_id},
            status=NotificationStatus.SENT,
            sent_at=timezone.now(),
        )
        logger.info("Confirmation email sent: registration=%s user=%s", registration_id, reg.user.email)

    except Exception as exc:
        logger.error("Confirmation email failed: registration=%s error=%s", registration_id, exc)
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_reminder_email(self, registration_id: str) -> None:
    """
    Send 24-hour reminder email.
    Triggered by schedule_event_reminders periodic task.
    """
    try:
        from apps.tickets.models import Registration

        reg = Registration.objects.select_related("user", "event").get(id=registration_id)
        _send_email(
            to=reg.user.email,
            subject=f"Reminder: {reg.event.title} is tomorrow!",
            template_base="reminder",
            context={
                "name":        reg.user.name,
                "event_title": reg.event.title,
                "start_at":    reg.event.start_at.strftime("%A, %B %d %Y at %I:%M %p UTC"),
                "venue_name":  reg.event.venue_name,
                "address":     reg.event.address,
                "online_url":  reg.event.online_url,
            },
        )
        logger.info("Reminder email sent: registration=%s user=%s", registration_id, reg.user.email)

    except Exception as exc:
        logger.error("Reminder email failed: registration=%s error=%s", registration_id, exc)
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_cancellation_email(self, registration_id: str) -> None:
    """
    Send cancellation confirmation when a paid registration is cancelled.
    """
    try:
        from apps.tickets.models import Registration

        reg = Registration.objects.select_related("user", "event", "tier").get(id=registration_id)
        _send_email(
            to=reg.user.email,
            subject=f"Your registration for {reg.event.title} has been cancelled",
            template_base="cancellation",
            context={
                "name":        reg.user.name,
                "event_title": reg.event.title,
                "tier_name":   reg.tier.name,
                "quantity":    reg.quantity,
            },
        )
        logger.info("Cancellation email sent: registration=%s user=%s", registration_id, reg.user.email)

    except Exception as exc:
        logger.error("Cancellation email failed: registration=%s error=%s", registration_id, exc)
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_approval_email(self, organizer_id: str, event_id: str) -> None:
    """Notify organizer their event was approved by admin."""
    try:
        from apps.users.models import User
        from apps.events.models import Event

        organizer = User.objects.get(id=organizer_id)
        event     = Event.objects.get(id=event_id)
        _send_email(
            to=organizer.email,
            subject=f"Your event '{event.title}' has been approved!",
            template_base="approval",
            context={"name": organizer.name, "event_title": event.title},
        )
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_rejection_email(self, organizer_id: str, event_id: str, reason: str) -> None:
    """Notify organizer their event was rejected by admin."""
    try:
        from apps.users.models import User
        from apps.events.models import Event

        organizer = User.objects.get(id=organizer_id)
        event     = Event.objects.get(id=event_id)
        _send_email(
            to=organizer.email,
            subject=f"Update on your event '{event.title}'",
            template_base="rejection",
            context={"name": organizer.name, "event_title": event.title, "reason": reason},
        )
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_password_reset_email(self, user_id: str, uid: str, token: str) -> None:
    """Send password reset link to the user."""
    try:
        from apps.users.models import User
        from django.conf import settings as conf

        user = User.objects.get(id=user_id)
        reset_url = f"{conf.FRONTEND_URL}/reset-password?token={uid}:{token}"
        _send_email(
            to=user.email,
            subject="Reset your Eventure password",
            template_base="password_reset",
            context={"name": user.name, "reset_url": reset_url},
        )
        logger.info("Password reset email sent: user=%s", user.email)
    except Exception as exc:
        logger.error("Password reset email failed: user=%s error=%s", user_id, exc)
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_event_cancelled_email(self, registration_id: str) -> None:
    """Notify an attendee that the event they registered for has been cancelled by the organizer."""
    try:
        from apps.tickets.models import Registration

        reg = Registration.objects.select_related("user", "event").get(id=registration_id)
        _send_email(
            to=reg.user.email,
            subject=f"Important update: {reg.event.title} has been cancelled",
            template_base="event_cancelled",
            context={
                "name":        reg.user.name,
                "event_title": reg.event.title,
                "start_at":    reg.event.start_at.strftime("%A, %B %d %Y at %I:%M %p UTC"),
            },
        )
        logger.info("Event cancellation email sent: registration=%s user=%s", registration_id, reg.user.email)
    except Exception as exc:
        logger.error("Event cancellation email failed: registration=%s error=%s", registration_id, exc)
        raise self.retry(exc=exc)


@shared_task
def schedule_event_reminders() -> int:
    """
    Periodic task — runs daily at midnight UTC via Celery Beat.

    Finds all CONFIRMED registrations for events starting in 23–25 hours
    and queues a reminder email for each attendee.
    Returns the count of reminder jobs queued.
    """
    from datetime import timedelta
    from apps.tickets.models import Registration, RegistrationStatus

    now   = timezone.now()
    start = now + timedelta(hours=23)
    end   = now + timedelta(hours=25)

    reg_ids = list(
        Registration.objects
        .filter(
            event__start_at__range=(start, end),
            status=RegistrationStatus.CONFIRMED,
        )
        .values_list("id", flat=True)
    )

    for reg_id in reg_ids:
        send_reminder_email.delay(str(reg_id))

    logger.info("Reminder scheduler queued %d emails.", len(reg_ids))
    return len(reg_ids)
