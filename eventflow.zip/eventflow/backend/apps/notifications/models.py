import uuid
from django.db import models
from django.conf import settings


class NotificationType(models.TextChoices):
    CONFIRMATION = 'CONFIRMATION', 'Confirmation'
    REMINDER     = 'REMINDER',     'Reminder'
    CANCELLATION = 'CANCELLATION', 'Cancellation'
    APPROVAL     = 'APPROVAL',     'Approval'
    REJECTION    = 'REJECTION',    'Rejection'


class NotificationStatus(models.TextChoices):
    QUEUED = 'QUEUED', 'Queued'
    SENT   = 'SENT',   'Sent'
    FAILED = 'FAILED', 'Failed'


class Notification(models.Model):
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user       = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                   related_name='notifications')
    type       = models.CharField(max_length=20, choices=NotificationType.choices)
    payload    = models.JSONField(default=dict)
    status     = models.CharField(max_length=10, choices=NotificationStatus.choices,
                                  default=NotificationStatus.QUEUED)
    sent_at    = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'notifications'
        indexes  = [models.Index(fields=['user', 'status'])]
