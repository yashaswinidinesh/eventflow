"""
apps/users/models.py
Component 1 — Auth, Users & Admin


Custom User model using email as the login identifier.
Role-based: ATTENDEE · ORGANIZER · ADMIN
"""
import uuid
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.db import models


class Role(models.TextChoices):
    ATTENDEE  = 'ATTENDEE',  'Attendee'
    ORGANIZER = 'ORGANIZER', 'Organizer'
    ADMIN     = 'ADMIN',     'Admin'


class UserManager(BaseUserManager):
    def get_by_natural_key(self, username):
        return self.get(**{f'{self.model.USERNAME_FIELD}__iexact': username})

    def create_user(self, email: str, password: str, **extra):
        if not email:
            raise ValueError('Email address is required.')
        email = self.normalize_email(email).lower()
        user  = self.model(email=email, **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email: str, password: str, **extra):
        extra.setdefault('role',         Role.ADMIN)
        extra.setdefault('is_staff',     True)
        extra.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra)


class User(AbstractBaseUser, PermissionsMixin):
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email      = models.EmailField(unique=True)
    name       = models.CharField(max_length=80)
    role       = models.CharField(max_length=20, choices=Role.choices, default=Role.ATTENDEE)
    bio        = models.TextField(blank=True)
    is_banned  = models.BooleanField(default=False)
    is_staff   = models.BooleanField(default=False)
    is_active  = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD  = 'email'
    REQUIRED_FIELDS = ['name']

    class Meta:
        db_table = 'users'
        indexes  = [models.Index(fields=['email'])]

    def __str__(self):
        return f'{self.name} <{self.email}>'

    # Convenience properties used by permission classes
    @property
    def is_attendee(self):
        return self.role == Role.ATTENDEE

    @property
    def is_organizer(self):
        return self.role == Role.ORGANIZER

    @property
    def is_admin_role(self):
        return self.role == Role.ADMIN
