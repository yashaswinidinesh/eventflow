from django.urls import path
from . import views

urlpatterns = [
    path('me/',           views.MeView.as_view(),             name='users-me'),
    path('<uuid:pk>/events/', views.OrganizerEventsView.as_view(), name='organizer-events'),
]
