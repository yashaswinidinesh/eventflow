from rest_framework import generics, permissions
from .models import User
from .serializers import UserPublicSerializer, UserProfileSerializer
from apps.events.serializers import EventListSerializer  # imported lazily


class MeView(generics.RetrieveUpdateAPIView):
    """GET /v1/users/me  — own profile. PUT to update."""
    serializer_class   = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user


class OrganizerEventsView(generics.ListAPIView):
    """GET /v1/users/:id/events — public list of events by organizer."""
    serializer_class   = EventListSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        from apps.events.models import Event
        return Event.objects.filter(
            organizer_id=self.kwargs['pk'],
            status='PUBLISHED',
        ).order_by('-start_at')
