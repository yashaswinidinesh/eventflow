from rest_framework import serializers
from .models import User


class UserPublicSerializer(serializers.ModelSerializer):
    """Safe public profile — no sensitive fields."""
    class Meta:
        model  = User
        fields = ['id', 'name', 'bio', 'role', 'created_at']
        read_only_fields = fields


class UserProfileSerializer(serializers.ModelSerializer):
    """Own profile — read/write."""
    class Meta:
        model  = User
        fields = ['id', 'email', 'name', 'bio', 'role', 'created_at', 'updated_at']
        read_only_fields = ['id', 'email', 'role', 'created_at', 'updated_at']
