"""
EventsService — Component 2

Responsibilities:
  - geocode(address) → (lat, lng) via Google Maps Geocoding API
  - generate_ical(event) → ical string
  - google_calendar_url(event) → pre-filled add-to-GCal URL
"""
import urllib.parse
from icalendar import Calendar, Event as ICalEvent
from datetime import datetime


def generate_ical(event) -> bytes:
    cal = Calendar()
    cal.add('prodid', '-//Eventure//eventure.app//')
    cal.add('version', '2.0')

    ical_event = ICalEvent()
    ical_event.add('uid',     str(event.id))
    ical_event.add('summary', event.title)
    ical_event.add('dtstart', event.start_at)
    ical_event.add('dtend',   event.end_at)
    ical_event.add('description', event.description[:500])
    if event.address:
        ical_event.add('location', event.address)

    cal.add_component(ical_event)
    return cal.to_ical()


def google_calendar_url(event) -> str:
    base = 'https://calendar.google.com/calendar/render'
    fmt  = '%Y%m%dT%H%M%SZ'
    params = {
        'action':   'TEMPLATE',
        'text':     event.title,
        'dates':    f"{event.start_at.strftime(fmt)}/{event.end_at.strftime(fmt)}",
        'details':  event.description[:500],
        'location': event.address or event.online_url or '',
    }
    return f"{base}?{urllib.parse.urlencode(params)}"


# TODO: implement geocode() using Google Maps Geocoding API
