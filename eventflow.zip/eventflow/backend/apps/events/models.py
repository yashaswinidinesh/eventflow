import uuid
from django.contrib.gis.db import models as gis_models
from django.db import models
from django.conf import settings


class EventStatus(models.TextChoices):
    DRAFT          = 'DRAFT',          'Draft'
    PENDING_REVIEW = 'PENDING_REVIEW', 'Pending Review'
    PUBLISHED      = 'PUBLISHED',      'Published'
    CANCELLED      = 'CANCELLED',      'Cancelled'


class Category(models.TextChoices):
    TECHNOLOGY = 'Technology', 'Technology'
    MUSIC      = 'Music',      'Music'
    FOOD_DRINK = 'Food & Drink', 'Food & Drink'
    ARTS       = 'Arts',       'Arts'
    SPORTS     = 'Sports',     'Sports'
    BUSINESS   = 'Business',   'Business'
    HEALTH     = 'Health',     'Health'
    EDUCATION  = 'Education',  'Education'
    NETWORKING = 'Networking', 'Networking'
    COMMUNITY  = 'Community',  'Community'


class Event(models.Model):
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    organizer   = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                    related_name='organized_events')
    title       = models.CharField(max_length=120)
    description = models.TextField()
    category    = models.CharField(max_length=50, choices=Category.choices)
    start_at    = models.DateTimeField()
    end_at      = models.DateTimeField()
    timezone    = models.CharField(max_length=50, default='UTC')
    venue_name  = models.CharField(max_length=200, blank=True)
    address     = models.CharField(max_length=300, blank=True)
    location    = gis_models.PointField(null=True, blank=True)  # PostGIS Point(lng, lat)
    is_online   = models.BooleanField(default=False)
    online_url  = models.URLField(blank=True)
    capacity    = models.PositiveIntegerField()
    status      = models.CharField(max_length=20, choices=EventStatus.choices,
                                   default=EventStatus.DRAFT)
    cover_image = models.URLField(blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'events'
        indexes  = [
            models.Index(fields=['status', 'start_at']),
            models.Index(fields=['organizer']),
            models.Index(fields=['category']),
        ]
        ordering = ['-start_at']

    def __str__(self):
        return self.title


class ScheduleSlot(models.Model):
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    event       = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='schedule_slots')
    title       = models.CharField(max_length=200)
    speaker     = models.CharField(max_length=100, blank=True)
    description = models.TextField(blank=True)
    starts_at   = models.DateTimeField()
    ends_at     = models.DateTimeField()

    class Meta:
        db_table = 'schedule_slots'
        ordering = ['starts_at']
