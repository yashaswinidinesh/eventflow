from django.http import HttpResponse
from django.contrib.gis.geos import Point
from django.contrib.gis.measure import D
from django.db.models import Q
from rest_framework import generics, status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView

from config.permissions import IsOrganizer
from .models import Event, EventStatus, Category
from .serializers import EventListSerializer, EventDetailSerializer, EventWriteSerializer
from .filters import EventFilter
from .services import generate_ical, google_calendar_url


class EventListCreateView(generics.ListCreateAPIView):
    """GET /v1/events/  POST /v1/events/"""
    filterset_class = EventFilter
    search_fields   = ['title', 'description', 'venue_name']
    ordering_fields = ['start_at', 'created_at']

    def get_permissions(self):
        if self.request.method == 'POST':
            return [IsOrganizer()]
        return [permissions.AllowAny()]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return EventWriteSerializer
        return EventListSerializer

    def get_queryset(self):
        # Organizer requesting their own events (all statuses)
        if self.request.query_params.get('mine') and self.request.user.is_authenticated:
            return Event.objects.filter(organizer=self.request.user).select_related('organizer').order_by('-created_at')

        qs = Event.objects.filter(status=EventStatus.PUBLISHED).select_related('organizer')

        # Geo radius filter
        lat    = self.request.query_params.get('lat')
        lng    = self.request.query_params.get('lng')
        radius = self.request.query_params.get('radius', 50)
        if lat and lng:
            point = Point(float(lng), float(lat), srid=4326)
            qs = qs.filter(location__distance_lte=(point, D(km=float(radius))))

        return qs

    def perform_create(self, serializer):
        serializer.save(organizer=self.request.user)


class EventDetailView(generics.RetrieveUpdateDestroyAPIView):
    """GET PUT DELETE /v1/events/:id/"""
    queryset = Event.objects.select_related('organizer').prefetch_related('schedule_slots')

    def get_permissions(self):
        if self.request.method == 'GET':
            return [permissions.AllowAny()]
        return [IsOrganizer()]

    def get_serializer_class(self):
        if self.request.method in ('PUT', 'PATCH'):
            return EventWriteSerializer
        return EventDetailSerializer

    def get_queryset(self):
        if self.request.method == 'GET':
            return Event.objects.filter(
                Q(status=EventStatus.PUBLISHED) | Q(organizer=self.request.user if self.request.user.is_authenticated else None)
            ).select_related('organizer').prefetch_related('schedule_slots')
        return Event.objects.filter(organizer=self.request.user)


class CancelEventView(APIView):
    """POST /v1/events/:id/cancel/"""
    permission_classes = [IsOrganizer]

    def post(self, request, pk):
        from apps.tickets.models import Registration, RegistrationStatus
        from apps.notifications.tasks import send_event_cancelled_email

        try:
            event = Event.objects.get(pk=pk, organizer=request.user)
        except Event.DoesNotExist:
            return Response({'error': 'Event not found.'}, status=status.HTTP_404_NOT_FOUND)

        if event.status == EventStatus.CANCELLED:
            return Response({'error': 'Event is already cancelled.'}, status=status.HTTP_400_BAD_REQUEST)

        event.status = EventStatus.CANCELLED
        event.save(update_fields=['status'])

        active_regs = Registration.objects.filter(
            event=event, status__in=[RegistrationStatus.CONFIRMED, RegistrationStatus.PENDING]
        )
        reg_ids = list(active_regs.values_list('id', flat=True))

        active_regs.update(status=RegistrationStatus.CANCELLED)

        for reg_id in reg_ids:
            send_event_cancelled_email.delay(str(reg_id))

        return Response({'status': 'cancelled', 'emails_queued': len(reg_ids)})


class PublishEventView(APIView):
    """POST /v1/events/:id/publish/"""
    permission_classes = [IsOrganizer]

    def post(self, request, pk):
        try:
            event = Event.objects.get(pk=pk, organizer=request.user)
        except Event.DoesNotExist:
            return Response({'error': {'code': 'NOT_FOUND', 'message': 'Event not found'}},
                            status=status.HTTP_404_NOT_FOUND)
        if event.status != EventStatus.DRAFT:
            return Response({'error': {'code': 'INVALID_STATUS', 'message': 'Only DRAFT events can be submitted'}},
                            status=status.HTTP_400_BAD_REQUEST)
        event.status = EventStatus.PENDING_REVIEW
        event.save(update_fields=['status'])
        # TODO: notify admin via Celery task
        return Response(EventDetailSerializer(event).data)


class EventIcalView(APIView):
    """GET /v1/events/:id/calendar.ics"""
    permission_classes = [permissions.AllowAny]

    def get(self, request, pk):
        try:
            event = Event.objects.get(pk=pk, status=EventStatus.PUBLISHED)
        except Event.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        ical_bytes = generate_ical(event)
        return HttpResponse(ical_bytes, content_type='text/calendar; charset=utf-8',
                            headers={'Content-Disposition': f'attachment; filename="event-{pk}.ics"'})


class EventGoogleCalendarView(APIView):
    """GET /v1/events/:id/google-calendar-link/"""
    permission_classes = [permissions.AllowAny]

    def get(self, request, pk):
        try:
            event = Event.objects.get(pk=pk, status=EventStatus.PUBLISHED)
        except Event.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        return Response({'url': google_calendar_url(event)})


class CategoryListView(APIView):
    """GET /v1/events/categories/"""
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        return Response([{'value': c.value, 'label': c.label} for c in Category])
