from rest_framework import serializers
from django.contrib.gis.geos import Point
from apps.users.serializers import UserPublicSerializer
from .models import Event, ScheduleSlot


class ScheduleSlotSerializer(serializers.ModelSerializer):
    class Meta:
        model  = ScheduleSlot
        fields = ['id', 'title', 'speaker', 'description', 'starts_at', 'ends_at']


class EventListSerializer(serializers.ModelSerializer):
    """Lightweight — used in list / card views."""
    organizer        = UserPublicSerializer(read_only=True)
    registered_count = serializers.SerializerMethodField()

    class Meta:
        model  = Event
        fields = [
            'id', 'title', 'category', 'start_at', 'end_at',
            'venue_name', 'address', 'is_online', 'capacity',
            'registered_count', 'status', 'cover_image', 'organizer',
        ]

    def get_registered_count(self, obj):
        return obj.registrations.filter(status='CONFIRMED').count()


class EventDetailSerializer(serializers.ModelSerializer):
    """Full detail including schedule and organizer."""
    organizer        = UserPublicSerializer(read_only=True)
    schedule_slots   = ScheduleSlotSerializer(many=True, read_only=True)
    lat              = serializers.SerializerMethodField()
    lng              = serializers.SerializerMethodField()
    registered_count = serializers.SerializerMethodField()

    class Meta:
        model  = Event
        fields = [
            'id', 'title', 'description', 'category',
            'start_at', 'end_at', 'timezone',
            'venue_name', 'address', 'lat', 'lng',
            'is_online', 'online_url',
            'capacity', 'registered_count', 'status', 'cover_image',
            'organizer', 'schedule_slots',
            'created_at', 'updated_at',
        ]

    def get_lat(self, obj):
        return obj.location.y if obj.location else None

    def get_lng(self, obj):
        return obj.location.x if obj.location else None

    def get_registered_count(self, obj):
        return obj.registrations.filter(status='CONFIRMED').count()


class EventWriteSerializer(serializers.ModelSerializer):
    """Create / update — organizer is set from request.user."""
    lat = serializers.FloatField(write_only=True, required=False)
    lng = serializers.FloatField(write_only=True, required=False)

    class Meta:
        model  = Event
        fields = [
            'id', 'title', 'description', 'category',
            'start_at', 'end_at', 'timezone',
            'venue_name', 'address', 'lat', 'lng',
            'is_online', 'online_url',
            'capacity', 'cover_image',
        ]
        read_only_fields = ['id']

    def validate(self, data):
        if data.get('end_at') and data.get('start_at'):
            if data['end_at'] <= data['start_at']:
                raise serializers.ValidationError({'end_at': 'Must be after start_at.'})
        return data

    def create(self, validated_data):
        lat = validated_data.pop('lat', None)
        lng = validated_data.pop('lng', None)
        if lat is not None and lng is not None:
            validated_data['location'] = Point(lng, lat)
        validated_data['organizer'] = self.context['request'].user
        return super().create(validated_data)

    def update(self, instance, validated_data):
        lat = validated_data.pop('lat', None)
        lng = validated_data.pop('lng', None)
        if lat is not None and lng is not None:
            validated_data['location'] = Point(lng, lat)
        return super().update(instance, validated_data)
