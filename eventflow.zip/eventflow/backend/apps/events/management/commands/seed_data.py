"""
Usage:
    python manage.py seed_data          # insert seed data (idempotent)
    python manage.py seed_data --flush  # wipe all app data first, then seed
"""
from django.core.management.base import BaseCommand
from django.contrib.gis.geos import Point
from django.utils import timezone
from django.db import transaction
from datetime import timedelta

from apps.users.models import User, Role
from apps.events.models import Event, EventStatus, ScheduleSlot
from apps.tickets.models import TicketTier


# ── Seed data ─────────────────────────────────────────────────────────────────

USERS = [
    dict(email='AdminUser@eventure.dev',      password='AdminUser123',      name='Admin User',      role=Role.ADMIN,     is_staff=True,  is_superuser=True),
    dict(email='AliceOrganizer@eventure.dev', password='AliceOrganizer123', name='Alice Organizer', role=Role.ORGANIZER),
    dict(email='BobOrganizer@eventure.dev',   password='BobOrganizer123',   name='Bob Organizer',   role=Role.ORGANIZER),
    dict(email='CarolAttendee@eventure.dev',  password='CarolAttendee123',  name='Carol Attendee',  role=Role.ATTENDEE),
    dict(email='DavidAttendee@eventure.dev',  password='DavidAttendee123',  name='David Attendee',  role=Role.ATTENDEE),
    dict(email='EveAttendee@eventure.dev',    password='EveAttendee123',    name='Eve Attendee',    role=Role.ATTENDEE),
]

# San Jose / Bay Area coordinates: Point(lng, lat)
EVENTS = [
    dict(
        title='SV Tech Summit 2026',
        description='A full-day conference covering AI, cloud infrastructure, and developer tooling for Silicon Valley engineers.',
        category='Technology',
        venue_name='San Jose Convention Center',
        address='150 W San Carlos St, San Jose, CA 95113',
        location=Point(-121.8863, 37.3294),
        capacity=500,
        price=49.99,
        tier_name='General Admission',
        days_from_now=14,
        duration_hours=8,
        organizer_idx=1,
    ),
    dict(
        title='Jazz in the Park',
        description='An outdoor evening of live jazz featuring local Bay Area artists. Bring a blanket and enjoy the music under the stars.',
        category='Music',
        venue_name='Guadalupe River Park',
        address='438 Coleman Ave, San Jose, CA 95110',
        location=Point(-121.8939, 37.3361),
        capacity=200,
        price=0,
        tier_name='Free Entry',
        days_from_now=7,
        duration_hours=3,
        organizer_idx=2,
    ),
    dict(
        title='Bay Area Food Fest',
        description='Taste food from 40+ local restaurants and food trucks. Wine and craft beer pairings included.',
        category='Food & Drink',
        venue_name='SAP Center Plaza',
        address='525 W Santa Clara St, San Jose, CA 95113',
        location=Point(-121.9010, 37.3327),
        capacity=800,
        price=25.00,
        tier_name='General Admission',
        days_from_now=21,
        duration_hours=5,
        organizer_idx=1,
    ),
    dict(
        title='Startup Networking Mixer',
        description='Connect with founders, investors, and engineers building the next wave of Bay Area startups. Light refreshments provided.',
        category='Networking',
        venue_name='WeWork Santana Row',
        address='3055 Olin Ave Suite 2000, San Jose, CA 95128',
        location=Point(-121.9479, 37.3233),
        capacity=100,
        price=15.00,
        tier_name='General',
        days_from_now=5,
        duration_hours=2,
        organizer_idx=2,
    ),
    dict(
        title='5K Fun Run — Downtown SJ',
        description='Community 5K run through downtown San Jose. All fitness levels welcome. Medals for finishers.',
        category='Sports',
        venue_name='Plaza de César Chávez',
        address='Market St, San Jose, CA 95113',
        location=Point(-121.8869, 37.3367),
        capacity=300,
        price=10.00,
        tier_name='Runner Registration',
        days_from_now=10,
        duration_hours=3,
        organizer_idx=1,
    ),
    dict(
        title='Python & Django Workshop',
        description='Hands-on half-day workshop building a REST API with Django and Django REST Framework. Laptop required.',
        category='Education',
        venue_name='SJSU Engineering Building',
        address='1 Washington Square, San Jose, CA 95192',
        location=Point(-121.8810, 37.3352),
        capacity=40,
        price=0,
        tier_name='Free — RSVP Required',
        days_from_now=3,
        duration_hours=4,
        organizer_idx=2,
    ),
    dict(
        title='Online: Product Management AMA',
        description='Live Q&A with senior PMs from top tech companies. Submit questions in advance via the event form.',
        category='Business',
        venue_name='',
        address='',
        location=None,
        capacity=1000,
        price=0,
        tier_name='Free Registration',
        days_from_now=2,
        duration_hours=1,
        is_online=True,
        online_url='https://meet.example.com/pm-ama',
        organizer_idx=1,
    ),
]


class Command(BaseCommand):
    help = 'Seed the database with demo users and events'

    def add_arguments(self, parser):
        parser.add_argument('--flush', action='store_true', help='Delete all existing app data before seeding')

    def handle(self, *args, **options):
        if options['flush']:
            self._flush()

        with transaction.atomic():
            users = self._seed_users()
            self._seed_events(users)

        self.stdout.write(self.style.SUCCESS('\nSeed complete. Test accounts:'))
        for u in USERS:
            self.stdout.write(f"  {u['role']:<12} {u['email']}  /  {u['password']}")

    def _flush(self):
        self.stdout.write('Flushing existing data...')
        ScheduleSlot.objects.all().delete()
        TicketTier.objects.all().delete()
        Event.objects.all().delete()
        User.objects.filter(email__endswith='@eventure.dev').delete()
        self.stdout.write('Done.\n')

    def _seed_users(self):
        created = []
        for u in USERS:
            u = u.copy()  # don't mutate the module-level list
            email = u['email']
            if User.objects.filter(email=email).exists():
                created.append(User.objects.get(email=email))
                self.stdout.write(f'  (exists) {email}')
                continue
            is_super = u.pop('is_superuser', False)
            is_staff = u.pop('is_staff', False)
            password = u.pop('password')
            user = User.objects.create_user(password=password, **u)
            user.is_superuser = is_super
            user.is_staff = is_staff
            user.save()
            created.append(user)
            self.stdout.write(f'  created  {email}')
        return created

    def _seed_events(self, users):
        now = timezone.now()
        organizers = [u for u in users if u.role == Role.ORGANIZER]

        for e in EVENTS:
            e = e.copy()  # don't mutate the module-level list
            organizer = organizers[e.pop('organizer_idx') - 1]
            price      = e.pop('price')
            tier_name  = e.pop('tier_name')
            days       = e.pop('days_from_now')
            hours      = e.pop('duration_hours')
            is_online  = e.pop('is_online', False)

            start_at = now + timedelta(days=days)
            end_at   = start_at + timedelta(hours=hours)

            existing = Event.objects.filter(title=e['title']).first()
            if existing:
                existing.start_at = start_at
                existing.end_at   = end_at
                existing.save(update_fields=['start_at', 'end_at'])
                self.stdout.write(f'  updated  {e["title"]} (dates refreshed)')
                continue

            event = Event.objects.create(
                organizer=organizer,
                start_at=start_at,
                end_at=end_at,
                status=EventStatus.PUBLISHED,
                is_online=is_online,
                **e,
            )
            TicketTier.objects.create(
                event=event,
                name=tier_name,
                price=price,
                quantity=event.capacity,
            )
            self.stdout.write(f'  created  {event.title}')
