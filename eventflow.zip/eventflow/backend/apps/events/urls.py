from django.urls import path
from . import views

urlpatterns = [
    path('',                              views.EventListCreateView.as_view(),    name='event-list-create'),
    path('categories/',                   views.CategoryListView.as_view(),       name='event-categories'),
    path('<uuid:pk>/',                    views.EventDetailView.as_view(),        name='event-detail'),
    path('<uuid:pk>/publish/',            views.PublishEventView.as_view(),       name='event-publish'),
    path('<uuid:pk>/cancel/',             views.CancelEventView.as_view(),        name='event-cancel'),
    path('<uuid:pk>/calendar.ics',        views.EventIcalView.as_view(),          name='event-ical'),
    path('<uuid:pk>/google-calendar-link/',views.EventGoogleCalendarView.as_view(),name='event-gcal'),
]
