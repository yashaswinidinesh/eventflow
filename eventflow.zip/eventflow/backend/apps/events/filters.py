import django_filters
from django.contrib.gis.geos import Point
from django.contrib.gis.measure import D
from .models import Event


class EventFilter(django_filters.FilterSet):
    category  = django_filters.CharFilter(lookup_expr='iexact')
    date_from = django_filters.DateTimeFilter(field_name='start_at', lookup_expr='gte')
    date_to   = django_filters.DateTimeFilter(field_name='start_at', lookup_expr='lte')
    is_online = django_filters.BooleanFilter()
    status    = django_filters.CharFilter()

    # Geo filter params (handled manually in the view)
    lat    = django_filters.NumberFilter(method='noop')
    lng    = django_filters.NumberFilter(method='noop')
    radius = django_filters.NumberFilter(method='noop')  # km

    class Meta:
        model  = Event
        fields = ['category', 'date_from', 'date_to', 'is_online', 'status']

    def noop(self, queryset, name, value):
        return queryset
