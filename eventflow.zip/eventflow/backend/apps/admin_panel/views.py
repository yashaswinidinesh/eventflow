"""
apps/admin_panel/views.py
Component 1 — Auth, Users & Admin


Admin-only endpoints:
  GET  /v1/admin/events/              — list all events (filter by status)
  PUT  /v1/admin/events/:id/approve/  — approve a pending event
  PUT  /v1/admin/events/:id/reject/   — reject with mandatory reason
  GET  /v1/admin/users/               — list all users
  PUT  /v1/admin/users/:id/ban/       — ban or unban a user
  GET  /v1/admin/audit-log/           — full audit trail
"""
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.authentication.permissions import IsAdmin
from apps.users.models import User
from .models import AuditLog, OrganizerRequest
from .serializers import AdminEventSerializer, AdminUserSerializer, AuditLogSerializer, OrganizerRequestSerializer


def _log(actor, action: str, target_type: str, target_id, notes: str = '') -> None:
    """Write one row to audit_logs."""
    AuditLog.objects.create(
        actor=actor,
        action=action,
        target_type=target_type,
        target_id=str(target_id),
        notes=notes,
    )


# ── Events ────────────────────────────────────────────────────────────────────

class AdminEventListView(generics.ListAPIView):
    """GET /v1/admin/events/?status=PENDING"""
    permission_classes = [IsAdmin]
    serializer_class   = AdminEventSerializer

    def get_queryset(self):
        from apps.events.models import Event
        qs     = Event.objects.select_related('organizer').order_by('-created_at')
        status_filter = self.request.query_params.get('status')
        if status_filter:
            qs = qs.filter(status=status_filter.upper())
        return qs


class AdminEventApproveView(APIView):
    """PUT /v1/admin/events/:id/approve/"""
    permission_classes = [IsAdmin]

    def put(self, request, pk):
        from apps.events.models import Event
        try:
            event = Event.objects.get(pk=pk)
        except Event.DoesNotExist:
            return Response({'error': 'Event not found.'}, status=status.HTTP_404_NOT_FOUND)

        if event.status != 'PENDING_REVIEW':
            return Response(
                {'error': f'Cannot approve event with status "{event.status}".'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        event.status = 'PUBLISHED'
        event.save(update_fields=['status'])
        _log(request.user, 'EVENT_APPROVED', 'Event', pk,
             notes=request.data.get('notes', ''))

        try:
            from apps.notifications.tasks import send_approval_email
            send_approval_email.delay(str(event.organizer_id), str(event.id))
        except Exception:
            pass

        return Response(AdminEventSerializer(event).data)


class AdminEventRejectView(APIView):
    """PUT /v1/admin/events/:id/reject/   — body: { reason }"""
    permission_classes = [IsAdmin]

    def put(self, request, pk):
        from apps.events.models import Event

        reason = (request.data.get('reason') or '').strip()
        if len(reason) < 5:
            return Response(
                {'error': 'A rejection reason (min 5 characters) is required.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            event = Event.objects.get(pk=pk)
        except Event.DoesNotExist:
            return Response({'error': 'Event not found.'}, status=status.HTTP_404_NOT_FOUND)

        if event.status != 'PENDING_REVIEW':
            return Response(
                {'error': f'Cannot reject event with status "{event.status}".'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        event.status = 'DRAFT'
        event.save(update_fields=['status'])
        _log(request.user, 'EVENT_REJECTED', 'Event', pk, notes=reason)

        try:
            from apps.notifications.tasks import send_rejection_email
            send_rejection_email.delay(str(event.organizer_id), str(event.id), reason)
        except Exception:
            pass

        return Response(AdminEventSerializer(event).data)


# ── Users ─────────────────────────────────────────────────────────────────────

class AdminUserListView(generics.ListAPIView):
    """GET /v1/admin/users/"""
    permission_classes = [IsAdmin]
    serializer_class   = AdminUserSerializer

    def get_queryset(self):
        qs   = User.objects.order_by('-created_at')
        role = self.request.query_params.get('role')
        if role:
            qs = qs.filter(role=role.upper())
        return qs


class AdminUserBanView(APIView):
    """PUT /v1/admin/users/:id/ban/   — body: { ban: true|false }"""
    permission_classes = [IsAdmin]

    def put(self, request, pk):
        try:
            user = User.objects.get(pk=pk)
        except User.DoesNotExist:
            return Response({'error': 'User not found.'}, status=status.HTTP_404_NOT_FOUND)

        ban = bool(request.data.get('ban', True))
        user.is_banned = ban
        user.save(update_fields=['is_banned'])

        action = 'USER_BANNED' if ban else 'USER_UNBANNED'
        _log(request.user, action, 'User', pk)

        return Response(AdminUserSerializer(user).data)


class AdminEventCancelView(APIView):
    """PUT /v1/admin/events/:id/cancel/"""
    permission_classes = [IsAdmin]

    def put(self, request, pk):
        from apps.events.models import Event
        try:
            event = Event.objects.get(pk=pk)
        except Event.DoesNotExist:
            return Response({'error': 'Event not found.'}, status=status.HTTP_404_NOT_FOUND)
        if event.status == 'CANCELLED':
            return Response({'error': 'Event is already cancelled.'}, status=status.HTTP_400_BAD_REQUEST)
        event.status = 'CANCELLED'
        event.save(update_fields=['status'])
        try:
            _log(request.user, 'EVENT_CANCELLED', 'Event', pk)
        except Exception:
            pass
        return Response(AdminEventSerializer(event).data)


class AdminEventDeleteView(APIView):
    """DELETE /v1/admin/events/:id/  — only allowed for CANCELLED events"""
    permission_classes = [IsAdmin]

    def delete(self, request, pk):
        from apps.events.models import Event
        try:
            event = Event.objects.get(pk=pk)
        except Event.DoesNotExist:
            return Response({'error': 'Event not found.'}, status=status.HTTP_404_NOT_FOUND)
        if event.status != 'CANCELLED':
            return Response({'error': 'Only cancelled events can be deleted.'}, status=status.HTTP_400_BAD_REQUEST)
        event.delete()
        try:
            _log(request.user, 'EVENT_DELETED', 'Event', pk)
        except Exception:
            pass
        return Response(status=status.HTTP_204_NO_CONTENT)


# ── Organizer Requests ────────────────────────────────────────────────────────

class OrganizerRequestListView(generics.ListAPIView):
    """GET /v1/admin/organizer-requests/?status=PENDING"""
    permission_classes = [IsAdmin]
    serializer_class   = OrganizerRequestSerializer

    def get_queryset(self):
        qs = OrganizerRequest.objects.select_related('user').order_by('-created_at')
        status_filter = self.request.query_params.get('status', 'PENDING')
        if status_filter:
            qs = qs.filter(status=status_filter.upper())
        return qs


class OrganizerRequestApproveView(APIView):
    """PUT /v1/admin/organizer-requests/:id/approve/"""
    permission_classes = [IsAdmin]

    def put(self, request, pk):
        from django.utils import timezone
        try:
            req = OrganizerRequest.objects.select_related('user').get(pk=pk)
        except OrganizerRequest.DoesNotExist:
            return Response({'error': 'Request not found.'}, status=status.HTTP_404_NOT_FOUND)
        if req.status != OrganizerRequest.STATUS_PENDING:
            return Response({'error': 'Request is not pending.'}, status=status.HTTP_400_BAD_REQUEST)
        req.status = OrganizerRequest.STATUS_APPROVED
        req.reviewed_at = timezone.now()
        req.save(update_fields=['status', 'reviewed_at'])
        req.user.role = 'ORGANIZER'
        req.user.save(update_fields=['role'])
        try:
            _log(request.user, 'ORGANIZER_APPROVED', 'User', req.user_id)
        except Exception:
            pass
        return Response(OrganizerRequestSerializer(req).data)


class OrganizerRequestRejectView(APIView):
    """PUT /v1/admin/organizer-requests/:id/reject/"""
    permission_classes = [IsAdmin]

    def put(self, request, pk):
        from django.utils import timezone
        try:
            req = OrganizerRequest.objects.select_related('user').get(pk=pk)
        except OrganizerRequest.DoesNotExist:
            return Response({'error': 'Request not found.'}, status=status.HTTP_404_NOT_FOUND)
        if req.status != OrganizerRequest.STATUS_PENDING:
            return Response({'error': 'Request is not pending.'}, status=status.HTTP_400_BAD_REQUEST)
        req.status = OrganizerRequest.STATUS_REJECTED
        req.reviewed_at = timezone.now()
        req.note = (request.data.get('note') or '').strip()
        req.save(update_fields=['status', 'reviewed_at', 'note'])
        try:
            _log(request.user, 'ORGANIZER_REJECTED', 'User', req.user_id)
        except Exception:
            pass
        return Response(OrganizerRequestSerializer(req).data)


# ── Audit log ─────────────────────────────────────────────────────────────────

class AuditLogView(generics.ListAPIView):
    """GET /v1/admin/audit-log/"""
    permission_classes = [IsAdmin]
    serializer_class   = AuditLogSerializer
    queryset = AuditLog.objects.select_related('actor').order_by('-created_at')
