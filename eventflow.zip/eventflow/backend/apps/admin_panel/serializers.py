"""
apps/admin_panel/serializers.py
Component 1 — Auth, Users & Admin

"""
from rest_framework import serializers
from apps.users.models import User
from .models import AuditLog, OrganizerRequest


class AdminEventSerializer(serializers.Serializer):
    """Read-only event summary for the admin queue."""
    id             = serializers.UUIDField(read_only=True)
    title          = serializers.CharField(read_only=True)
    status         = serializers.CharField(read_only=True)
    organizer_name = serializers.SerializerMethodField()
    category_name  = serializers.SerializerMethodField()
    start_at       = serializers.DateTimeField(read_only=True)
    created_at     = serializers.DateTimeField(read_only=True)

    def get_organizer_name(self, obj):
        return obj.organizer.name if obj.organizer else None

    def get_category_name(self, obj):
        return obj.category if obj.category else None


class OrganizerRequestSerializer(serializers.ModelSerializer):
    user_name  = serializers.CharField(source='user.name',  read_only=True)
    user_email = serializers.CharField(source='user.email', read_only=True)

    class Meta:
        model  = OrganizerRequest
        fields = ['id', 'user_name', 'user_email', 'status', 'note', 'created_at', 'reviewed_at']


class AdminUserSerializer(serializers.ModelSerializer):
    class Meta:
        model  = User
        fields = ['id', 'email', 'name', 'role', 'is_banned', 'is_active', 'created_at']
        read_only_fields = fields


class AuditLogSerializer(serializers.ModelSerializer):
    actor_name  = serializers.CharField(source='actor.name',  read_only=True, default=None)
    actor_email = serializers.CharField(source='actor.email', read_only=True, default=None)

    class Meta:
        model  = AuditLog
        fields = [
            'id', 'action', 'target_type', 'target_id',
            'notes', 'actor_name', 'actor_email', 'created_at',
        ]
