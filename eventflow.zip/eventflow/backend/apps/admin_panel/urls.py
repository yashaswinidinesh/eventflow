"""
apps/admin_panel/urls.py
Component 1 — Auth, Users & Admin


Mounted at /v1/admin/ in config/urls.py
"""
from django.urls import path
from .views import (
    AdminEventApproveView,
    AdminEventCancelView,
    AdminEventDeleteView,
    AdminEventListView,
    AdminEventRejectView,
    AdminUserBanView,
    AdminUserListView,
    AuditLogView,
    OrganizerRequestListView,
    OrganizerRequestApproveView,
    OrganizerRequestRejectView,
)

urlpatterns = [
    # Events moderation
    path('events/',                     AdminEventListView.as_view(),    name='admin-event-list'),
    path('events/<uuid:pk>/approve/',   AdminEventApproveView.as_view(), name='admin-event-approve'),
    path('events/<uuid:pk>/reject/',    AdminEventRejectView.as_view(),  name='admin-event-reject'),
    path('events/<uuid:pk>/cancel/',    AdminEventCancelView.as_view(),  name='admin-event-cancel'),
    path('events/<uuid:pk>/',           AdminEventDeleteView.as_view(),  name='admin-event-delete'),

    # User management
    path('users/',                      AdminUserListView.as_view(),     name='admin-user-list'),
    path('users/<uuid:pk>/ban/',        AdminUserBanView.as_view(),      name='admin-user-ban'),

    # Organizer requests
    path('organizer-requests/',                          OrganizerRequestListView.as_view(),    name='organizer-request-list'),
    path('organizer-requests/<uuid:pk>/approve/',        OrganizerRequestApproveView.as_view(), name='organizer-request-approve'),
    path('organizer-requests/<uuid:pk>/reject/',         OrganizerRequestRejectView.as_view(),  name='organizer-request-reject'),

    # Audit trail
    path('audit-log/',                  AuditLogView.as_view(),          name='admin-audit-log'),
]
