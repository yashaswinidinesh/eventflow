"""
AdminService — Component 1

Writes audit log entries for every moderation action.
"""
from .models import AuditLog


def log(actor, action: str, target_type: str, target_id: str, metadata: dict = None):
    AuditLog.objects.create(
        actor=actor, action=action,
        target_type=target_type, target_id=str(target_id),
        metadata=metadata or {},
    )
