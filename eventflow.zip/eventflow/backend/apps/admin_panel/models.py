"""
apps/admin_panel/models.py
Component 1 — Auth, Users & Admin


AuditLog: records every admin moderation action.
"""
import uuid
from django.conf import settings
from django.db import models


class OrganizerRequest(models.Model):
    STATUS_PENDING  = 'PENDING'
    STATUS_APPROVED = 'APPROVED'
    STATUS_REJECTED = 'REJECTED'
    STATUS_CHOICES  = [(STATUS_PENDING, 'Pending'), (STATUS_APPROVED, 'Approved'), (STATUS_REJECTED, 'Rejected')]

    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user       = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='organizer_request')
    status     = models.CharField(max_length=10, choices=STATUS_CHOICES, default=STATUS_PENDING)
    note       = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'organizer_requests'
        ordering = ['-created_at']

    def __str__(self):
        return f'OrganizerRequest({self.user_id}, {self.status})'


class AuditLog(models.Model):
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    actor       = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='audit_actions',
    )
    action      = models.CharField(max_length=64)   # e.g. EVENT_APPROVED, USER_BANNED
    target_type = models.CharField(max_length=32)   # e.g. Event, User
    target_id   = models.CharField(max_length=64)
    notes       = models.TextField(blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'audit_logs'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.action} by {self.actor_id} on {self.target_type}:{self.target_id}'
