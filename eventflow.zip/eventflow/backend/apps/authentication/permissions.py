"""
apps/authentication/permissions.py
Component 1 — Auth, Users & Admin


Role guards used by all other components. Import like:
    from apps.authentication.permissions import IsAdmin, IsOrganizer, IsAttendee
"""
from rest_framework.permissions import BasePermission


class IsAttendee(BasePermission):
    """Allow only authenticated users with role == ATTENDEE."""
    message = 'Only attendees can perform this action.'

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role == 'ATTENDEE'
        )


class IsOrganizer(BasePermission):
    """Allow only authenticated users with role == ORGANIZER."""
    message = 'Only organizers can perform this action.'

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role == 'ORGANIZER'
        )


class IsAdmin(BasePermission):
    """Allow only authenticated users with role == ADMIN."""
    message = 'Admin access required.'

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role == 'ADMIN'
        )


class IsOrganizerOrAdmin(BasePermission):
    """Allow ORGANIZER or ADMIN — used for shared moderation views."""
    message = 'Organizer or admin access required.'

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated
            and request.user.role in ('ORGANIZER', 'ADMIN')
        )


class IsOwnerOrAdmin(BasePermission):
    """
    Object-level: allow if the user owns the object or has role ADMIN.
    The object must expose an `organizer` or `user` attribute pointing to a User.
    Used by Events, Tickets, etc.
    """
    message = 'You do not have permission to modify this resource.'

    def has_object_permission(self, request, view, obj):
        if request.user.role == 'ADMIN':
            return True
        owner = getattr(obj, 'organizer', None) or getattr(obj, 'user', None)
        return owner == request.user
