"""
apps/authentication/services.py
Component 1 — Auth, Users & Admin


Functions:
  issue_tokens(user)              → { access, refresh }
  blacklist_token(refresh_str)    → logout / raises on bad token
  send_password_reset(email)      → queues Celery task (silent if email not found)
  reset_password(token, password) → validates signed token, updates hash
"""
import logging

from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from rest_framework_simplejwt.tokens import RefreshToken

from apps.users.models import User

logger = logging.getLogger(__name__)

_token_generator = PasswordResetTokenGenerator()


# ── JWT ──────────────────────────────────────────────────────────────────────

def issue_tokens(user) -> dict:
    """Return a fresh { access, refresh } pair. Role is embedded in access payload."""
    refresh = RefreshToken.for_user(user)
    refresh['role'] = user.role           # Frontend can read role without decoding manually
    return {
        'access':  str(refresh.access_token),
        'refresh': str(refresh),
    }


def blacklist_token(refresh_token_str: str) -> None:
    """Blacklist a refresh token. Raises TokenError on invalid/already-blacklisted input."""
    token = RefreshToken(refresh_token_str)
    token.blacklist()


# ── Password reset ────────────────────────────────────────────────────────────

def send_password_reset(email: str) -> None:
    """
    Queue a password-reset email if the address belongs to an active account.
    Always returns silently — callers must not reveal whether the email exists.

    Token format sent to the client:  '<uid_b64>:<django_token>'
    Both parts combined so the client submits a single field.
    """
    try:
        user = User.objects.get(email__iexact=email, is_active=True)
    except User.DoesNotExist:
        return  # Silent — do not enumerate registered emails

    uid   = urlsafe_base64_encode(force_bytes(user.pk))
    token = _token_generator.make_token(user)

    try:
        from apps.notifications.tasks import send_password_reset_email
        send_password_reset_email.delay(str(user.id), uid, token)
    except Exception:
        logger.exception('Failed to queue password-reset email for user %s', user.id)


def reset_password(token: str, new_password: str) -> bool:
    """
    Validate a '<uid_b64>:<django_token>' pair and apply the new password.

    Returns True on success, False if the token is invalid or expired.
    Uses Django's built-in PasswordResetTokenGenerator so tokens expire
    after PASSWORD_RESET_TIMEOUT seconds (default 3 days).
    """
    try:
        uid_b64, reset_token = token.split(':', 1)
        uid  = force_str(urlsafe_base64_decode(uid_b64))
        user = User.objects.get(pk=uid, is_active=True)
    except Exception:
        return False

    if not _token_generator.check_token(user, reset_token):
        return False

    user.set_password(new_password)
    user.save(update_fields=['password', 'updated_at'])
    return True
