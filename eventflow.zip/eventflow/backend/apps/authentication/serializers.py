"""
apps/authentication/serializers.py
Component 1 — Auth, Users & Admin

"""
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from apps.users.models import User, Role


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        min_length=8,
        style={'input_type': 'password'},
    )
    # Attendees and organizers can self-register; ADMIN is assigned internally only
    role = serializers.ChoiceField(
        choices=[Role.ATTENDEE, Role.ORGANIZER],
        default=Role.ATTENDEE,
    )

    class Meta:
        model  = User
        fields = ['id', 'email', 'name', 'password', 'role']
        read_only_fields = ['id']

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError('A user with this email already exists.')
        return value.lower()

    def validate_password(self, value):
        validate_password(value)
        return value

    def create(self, validated_data):
        requested_organizer = validated_data.get('role') == Role.ORGANIZER
        if requested_organizer:
            validated_data['role'] = Role.ATTENDEE
        user = User.objects.create_user(**validated_data)
        if requested_organizer:
            from apps.admin_panel.models import OrganizerRequest
            OrganizerRequest.objects.create(user=user)
        return user


class LoginSerializer(serializers.Serializer):
    email    = serializers.EmailField()
    password = serializers.CharField(
        write_only=True,
        style={'input_type': 'password'},
    )

    def validate(self, data):
        user = authenticate(
            email=data['email'],
            password=data['password'],
        )
        if not user:
            raise serializers.ValidationError(
                'Invalid email or password.',
                code='invalid_credentials',
            )
        if user.is_banned:
            raise serializers.ValidationError(
                'Your account has been suspended. Please contact support.',
                code='account_banned',
            )
        if not user.is_active:
            raise serializers.ValidationError(
                'Account is inactive.',
                code='account_inactive',
            )
        data['user'] = user
        return data


class ForgotPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()


class ResetPasswordSerializer(serializers.Serializer):
    token        = serializers.CharField(min_length=10)
    new_password = serializers.CharField(
        min_length=8,
        write_only=True,
        style={'input_type': 'password'},
    )

    def validate_new_password(self, value):
        validate_password(value)
        return value


class UserProfileSerializer(serializers.ModelSerializer):
    """Safe profile — never returns password_hash."""
    class Meta:
        model  = User
        fields = ['id', 'email', 'name', 'bio', 'role', 'created_at', 'updated_at']
        read_only_fields = ['id', 'email', 'role', 'created_at', 'updated_at']
