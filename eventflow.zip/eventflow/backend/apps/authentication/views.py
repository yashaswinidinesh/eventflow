"""
apps/authentication/views.py
Component 1 — Auth, Users & Admin


Endpoints handled here:
  POST /v1/auth/register/         RegisterView
  POST /v1/auth/login/            LoginView
  POST /v1/auth/logout/           LogoutView
  POST /v1/auth/token/refresh/    → simplejwt TokenRefreshView (wired in urls.py)
  POST /v1/auth/forgot-password/  ForgotPasswordView
  POST /v1/auth/reset-password/   ResetPasswordView
  GET  /v1/auth/me/               MeView
  PUT  /v1/auth/me/               MeView (partial update)
"""
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import (
    ForgotPasswordSerializer,
    LoginSerializer,
    RegisterSerializer,
    ResetPasswordSerializer,
    UserProfileSerializer,
)
from .services import (
    blacklist_token,
    issue_tokens,
    reset_password,
    send_password_reset,
)


class RegisterView(APIView):
    """POST /v1/auth/register/"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        from django.db import IntegrityError
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            user = serializer.save()
        except IntegrityError:
            return Response(
                {'email': ['A user with this email already exists.']},
                status=status.HTTP_400_BAD_REQUEST,
            )
        tokens = issue_tokens(user)
        return Response(
            {'user': UserProfileSerializer(user).data, 'tokens': tokens},
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    """POST /v1/auth/login/"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user   = serializer.validated_data['user']
        tokens = issue_tokens(user)
        return Response({'user': UserProfileSerializer(user).data, 'tokens': tokens})


class LogoutView(APIView):
    """POST /v1/auth/logout/   — body: { refresh: '<token>' }"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        refresh = request.data.get('refresh')
        if not refresh:
            return Response(
                {'error': 'refresh token is required'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        try:
            blacklist_token(refresh)
        except Exception:
            # Already blacklisted or invalid — still treat as successful logout
            pass
        return Response(status=status.HTTP_204_NO_CONTENT)


class ForgotPasswordView(APIView):
    """POST /v1/auth/forgot-password/   — body: { email }"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ForgotPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        send_password_reset(serializer.validated_data['email'])
        # Always the same message — never reveal if the email is registered
        return Response(
            {'message': 'If that email is registered, a reset link has been sent.'}
        )


class ResetPasswordView(APIView):
    """POST /v1/auth/reset-password/   — body: { token, new_password }"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ResetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        success = reset_password(
            token=serializer.validated_data['token'],
            new_password=serializer.validated_data['new_password'],
        )
        if not success:
            return Response(
                {'error': 'Reset token is invalid or has expired.'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return Response({'message': 'Password updated successfully.'})


class MeView(APIView):
    """GET + PUT /v1/auth/me/"""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserProfileSerializer(request.user).data)

    def put(self, request):
        serializer = UserProfileSerializer(
            request.user,
            data=request.data,
            partial=True,
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
