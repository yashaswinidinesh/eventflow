from rest_framework.views import exception_handler
from rest_framework.response import Response


def custom_exception_handler(exc, context):
    response = exception_handler(exc, context)

    if response is not None:
        code = getattr(exc, 'default_code', 'error').upper()
        response.data = {
            'error': {
                'code':    code,
                'message': str(exc),
                'details': response.data if isinstance(response.data, dict) else None,
            }
        }
    return response
