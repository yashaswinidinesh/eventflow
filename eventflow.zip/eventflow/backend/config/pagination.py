from rest_framework.pagination import PageNumberPagination

class StandardPagination(PageNumberPagination):
    page_size              = 20
    page_size_query_param  = 'limit'
    max_page_size          = 50

    def get_paginated_response_schema(self, schema):
        return {
            'type': 'object',
            'properties': {
                'count':    {'type': 'integer'},
                'next':     {'type': 'string', 'nullable': True},
                'previous': {'type': 'string', 'nullable': True},
                'results':  schema,
            }
        }
