from .base import *  # noqa
import os

DEBUG = False

ALLOWED_HOSTS = env.list('ALLOWED_HOSTS')  # noqa

SECURE_SSL_REDIRECT             = True
SECURE_HSTS_SECONDS             = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS  = True
SECURE_HSTS_PRELOAD             = True
SESSION_COOKIE_SECURE           = True
CSRF_COOKIE_SECURE              = True
