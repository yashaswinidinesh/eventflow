import os
import sys

from .base import *  # noqa

DEBUG = True

ALLOWED_HOSTS = ['localhost', '127.0.0.1', '0.0.0.0']

# GDAL/GEOS paths — only needed on Windows (native local dev, not Docker).
# Docker (Linux) and macOS find these libraries automatically via the system.
# Override via env vars if your PostgreSQL/PostGIS is installed to a non-default path.
if sys.platform == 'win32':
    GDAL_LIBRARY_PATH = os.environ.get(
        'GDAL_LIBRARY_PATH',
        r'C:\Program Files\PostgreSQL\18\bin\libgdal-35.dll',
    )
    GEOS_LIBRARY_PATH = os.environ.get(
        'GEOS_LIBRARY_PATH',
        r'C:\Program Files\PostgreSQL\18\bin\libgeos_c.dll',
    )
