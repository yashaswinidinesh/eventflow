from .base import *  # noqa

DEBUG = True

DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': 'eventure_test',
        'USER': 'eventure',
        'PASSWORD': 'eventure',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}

EMAIL_BACKEND = 'django.core.mail.backends.locmem.EmailBackend'

CELERY_TASK_ALWAYS_EAGER = True   # Run tasks synchronously in tests
CELERY_TASK_EAGER_PROPAGATES = True
