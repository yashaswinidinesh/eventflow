from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('django-admin/', admin.site.urls),

    # API v1
    path('v1/auth/',    include('apps.authentication.urls')),
    path('v1/users/',   include('apps.users.urls')),
    path('v1/events/',  include('apps.events.urls')),
    path('v1/tickets/', include('apps.tickets.urls')),
    path('v1/payments/',include('apps.payments.urls')),
    path('v1/admin/',   include('apps.admin_panel.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
