import pytest
from django.urls import reverse


@pytest.mark.django_db
class TestRegister:
    def test_register_attendee_returns_201(self, client):
        res = client.post(reverse('auth-register'), {
            'email': 'new@test.com', 'password': 'Secure@123', 'name': 'New User', 'role': 'ATTENDEE'
        }, content_type='application/json')
        assert res.status_code == 201
        assert 'tokens' in res.json()

    def test_register_duplicate_email_returns_400(self, client, attendee):
        res = client.post(reverse('auth-register'), {
            'email': attendee.email, 'password': 'Secure@123', 'name': 'Dup'
        }, content_type='application/json')
        assert res.status_code in (400, 422)

    def test_register_weak_password_returns_422(self, client):
        res = client.post(reverse('auth-register'), {
            'email': 'weak@test.com', 'password': '123', 'name': 'Weak'
        }, content_type='application/json')
        assert res.status_code == 400


@pytest.mark.django_db
class TestLogin:
    def test_valid_credentials_returns_tokens(self, client, attendee):
        res = client.post(reverse('auth-login'), {
            'email': attendee.email, 'password': 'Test@1234'
        }, content_type='application/json')
        assert res.status_code == 200
        data = res.json()
        assert 'access' in data['tokens']
        assert 'refresh' in data['tokens']

    def test_wrong_password_returns_400(self, client, attendee):
        res = client.post(reverse('auth-login'), {
            'email': attendee.email, 'password': 'wrong'
        }, content_type='application/json')
        assert res.status_code == 400
