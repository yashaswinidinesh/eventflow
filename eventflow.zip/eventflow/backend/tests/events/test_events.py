import pytest
from django.urls import reverse
from apps.events.models import Event, EventStatus


@pytest.fixture
def published_event(db, organizer):
    return Event.objects.create(
        organizer=organizer, title='Test Event', description='A test event description.',
        category='Technology', start_at='2026-12-01T10:00:00Z', end_at='2026-12-01T14:00:00Z',
        capacity=100, status=EventStatus.PUBLISHED,
    )


@pytest.mark.django_db
class TestEventList:
    def test_public_can_list_published_events(self, client, published_event):
        res = client.get(reverse('event-list-create'))
        assert res.status_code == 200
        assert res.json()['count'] >= 1

    def test_create_requires_organizer_role(self, client, attendee_token):
        res = client.post(reverse('event-list-create'),
            {'title': 'X', 'description': 'Y' * 10, 'category': 'Technology',
             'start_at': '2026-12-01T10:00:00Z', 'end_at': '2026-12-01T14:00:00Z', 'capacity': 50},
            content_type='application/json',
            HTTP_AUTHORIZATION=f'Bearer {attendee_token}')
        assert res.status_code == 403

    def test_organizer_can_create_event(self, client, organizer_token):
        res = client.post(reverse('event-list-create'), {
            'title': 'New Event', 'description': 'Great event description here.',
            'category': 'Technology', 'start_at': '2026-12-01T10:00:00Z',
            'end_at': '2026-12-01T14:00:00Z', 'capacity': 50,
        }, content_type='application/json', HTTP_AUTHORIZATION=f'Bearer {organizer_token}')
        assert res.status_code == 201
        assert res.json()['status'] == 'DRAFT'
