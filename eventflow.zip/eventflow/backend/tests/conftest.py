import pytest
from django.contrib.auth import get_user_model

User = get_user_model()


@pytest.fixture
def attendee(db):
    return User.objects.create_user(
        email='attendee@test.com', password='Test@1234', name='Test Attendee', role='ATTENDEE'
    )


@pytest.fixture
def organizer(db):
    return User.objects.create_user(
        email='organizer@test.com', password='Test@1234', name='Test Organizer', role='ORGANIZER'
    )


@pytest.fixture
def admin_user(db):
    return User.objects.create_user(
        email='admin@test.com', password='Test@1234', name='Admin User', role='ADMIN', is_staff=True
    )


@pytest.fixture
def attendee_token(attendee):
    from apps.authentication.services import issue_tokens
    return issue_tokens(attendee)['access']


@pytest.fixture
def organizer_token(organizer):
    from apps.authentication.services import issue_tokens
    return issue_tokens(organizer)['access']


@pytest.fixture
def admin_token(admin_user):
    from apps.authentication.services import issue_tokens
    return issue_tokens(admin_user)['access']
