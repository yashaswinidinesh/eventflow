import pytest
from django.urls import reverse
from apps.events.models import Event, EventStatus
from apps.tickets.models import TicketTier


@pytest.fixture
def free_event_with_tier(db, organizer):
    event = Event.objects.create(
        organizer=organizer, title='Free Event', description='Free event description here.',
        category='Music', start_at='2026-12-01T10:00:00Z', end_at='2026-12-01T14:00:00Z',
        capacity=10, status=EventStatus.PUBLISHED,
    )
    tier = TicketTier.objects.create(event=event, name='General', price=0, quantity=10)
    return event, tier


@pytest.mark.django_db
class TestRegistration:
    def test_attendee_can_register_free_event(self, client, attendee_token, free_event_with_tier):
        event, tier = free_event_with_tier
        res = client.post(
            reverse('event-register', kwargs={'event_pk': event.pk}),
            {'tier_id': str(tier.pk), 'quantity': 1},
            content_type='application/json',
            HTTP_AUTHORIZATION=f'Bearer {attendee_token}',
        )
        assert res.status_code == 201
        assert res.json()['status'] == 'CONFIRMED'

    def test_registration_requires_auth(self, client, free_event_with_tier):
        event, tier = free_event_with_tier
        res = client.post(
            reverse('event-register', kwargs={'event_pk': event.pk}),
            {'tier_id': str(tier.pk), 'quantity': 1},
            content_type='application/json',
        )
        assert res.status_code == 401

    def test_over_capacity_returns_400(self, client, attendee_token, free_event_with_tier):
        event, tier = free_event_with_tier
        tier.sold = 10
        tier.save()
        res = client.post(
            reverse('event-register', kwargs={'event_pk': event.pk}),
            {'tier_id': str(tier.pk), 'quantity': 1},
            content_type='application/json',
            HTTP_AUTHORIZATION=f'Bearer {attendee_token}',
        )
        assert res.status_code == 400
